package com.spring.pjt.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.spring.pjt.dto.memberDto;

@Repository
public interface memberDao {
	
	public ArrayList<memberDto> selectMemberGroup();
	public memberDto selectMemberbyId(String id);
	public void insertMember(memberDto member);
	public void updateMember(memberDto member);
	public void deleteMemeber(String id);
	public int userCheck(memberDto member);
	
	
}
