package com.spring.pjt.service;

import java.util.ArrayList;

import com.spring.pjt.dto.memberDto;

public interface memberService {
	
	public ArrayList<memberDto> selectMemberGroup();
	public memberDto selectMemberbyId(String id);
	public void insertMember(memberDto member);
	public void updateMember(memberDto member);
	public void deleteMember(String id);
	public int userCheck(memberDto member);
}
