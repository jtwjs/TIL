package com.spring.pjt.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.pjt.dao.memberDao;
import com.spring.pjt.dto.memberDto;

@Service
public class memberServiceImp implements memberService {
	
	@Autowired
	memberDao dao;
	
	@Override
	public ArrayList<memberDto> selectMemberGroup() {
		ArrayList<memberDto> memberGroup = dao.selectMemberGroup();
		return memberGroup;
	}

	@Override
	public memberDto selectMemberbyId(String id) {
		memberDto member = dao.selectMemberbyId(id);
		return member;
	}

	@Override
	public void insertMember(memberDto member) {
		dao.insertMember(member);

	}

	@Override
	public void updateMember(memberDto member) {
		dao.updateMember(member);

	}

	@Override
	public void deleteMember(String id) {
		dao.deleteMemeber(id);

	}

	@Override
	public int userCheck(memberDto member) {
		int result = dao.userCheck(member);
		return result;
	}

}
