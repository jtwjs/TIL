package com.spring.pjt.controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.pjt.dto.memberDto;
import com.spring.pjt.service.memberService;

@Controller
public class memberController {

	@Autowired
	memberService service;
	
	@RequestMapping(value = "main.me", method = RequestMethod.GET)
	public String main() {
		
		return "main";
	}
	
	@RequestMapping(value = "joinFrom.me", method = RequestMethod.GET)
	public String joinForm() {
		
		return "joinForm";
	}
	
	@RequestMapping(value = "join.me", method = RequestMethod.POST)
	public String join(@ModelAttribute("mem") memberDto member) {
		service.insertMember(member);
		
		return "redirect:main";
	}
	
	@RequestMapping(value = "updae.me", method = RequestMethod.POST)
	public String update(@ModelAttribute("mem") memberDto member)
	{
		service.updateMember(member);
		
		return "redirect:main";
	}
	
	@RequestMapping(value = "delete.me", method = RequestMethod.GET)
	public String delete(@ModelAttribute("mem") memberDto member){
		String id = member.getmId();
		service.deleteMember(id);
		
		return "redirect:main";
	}
	
	
	@RequestMapping(value = "login.me", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	@ResponseBody
	public HashMap<String, Object> login(@RequestBody memberDto member,HttpSession session) {
		
		int result = service.userCheck(member);
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		if(result != 0) {
			map.put("res","loginSuccess");
			session.setAttribute("member",member);
		}
		else {
			map.put("res","loginFail");
		}
		return map;
		}
	@RequestMapping(value ="logout.me", method = RequestMethod.GET)
	public String logout(HttpSession session){
			session.invalidate();
			return "redirect:main";
	}
	
	
}
