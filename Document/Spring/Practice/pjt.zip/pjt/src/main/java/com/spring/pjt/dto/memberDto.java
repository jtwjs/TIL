package com.spring.pjt.dto;

public class memberDto {

	private String mId;
	private String mPw;
	private String mName;
	private int mTel;
	private String mMal;
	private String mBloodType;
	public String getmId() {
		return mId;
	}
	public void setmId(String mId) {
		this.mId = mId;
	}
	public String getmPw() {
		return mPw;
	}
	public void setmPw(String mPw) {
		this.mPw = mPw;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public int getmTel() {
		return mTel;
	}
	public void setmTel(int mTel) {
		this.mTel = mTel;
	}
	public String getmMal() {
		return mMal;
	}
	public void setmMal(String mMal) {
		this.mMal = mMal;
	}
	public String getmBloadType() {
		return mBloodType;
	}
	public void setmBloadType(String mBloadType) {
		this.mBloodType = mBloadType;
	}
	
	
	
}
